let btn = document.querySelector('.btn img');
localStorage.setItem('isMoon' , 'false');

let menu = document.querySelector('.menu-par');

let arrow = document.querySelector('.mm');

let isMoon = false;

let black = `
    .O {
        fill: none;
        stroke: rgba(255, 255, 255, 0.8)  !important;
        stroke-width: 0.5;
        stroke-linecap: round;
        stroke-miterlimit: 10;
    }`;

let white = `
    .O {
        fill: none;
        stroke: rgba(0, 0, 0, 0.8)  !important;
        stroke-width: 0.5;
        stroke-linecap: round;
        stroke-miterlimit: 10;
    }`;

let dtp = document.querySelector('.O');

btn.addEventListener('click' , (e) => {
    if(!isMoon) {
        console.log('asfs');
        isMoon = true;
        btn.classList.add('rot');
        btn.setAttribute('src' , 'res/sun.svg');
        arrow.setAttribute('src' , 'res/white__menu.svg')
        document.body.style.color = 'rgba(255, 255, 255, 0.8)';
        menu.style.background = 'rgba(0, 0, 0, 0.8)';
        document.body.style.background = 'rgba(0,0,0,.8)';
        if(dtp) {
            head = document.querySelector('body');
            style = document.createElement('style');
        
            head.appendChild(style);
            
            style.type = 'text/css';
            if (style.styleSheet){
            // This is required for IE8 and below.
            style.styleSheet.cssText = black;
            } else {
            style.appendChild(document.createTextNode(black));
            }
        }
        
    } else {
        if(dtp) {
            head = document.querySelector('body');
            style = document.createElement('style');
        
            head.appendChild(style);
            
            style.type = 'text/css';
            if (style.styleSheet){
            // This is required for IE8 and below.
            style.styleSheet.cssText = white;
            } else {
            style.appendChild(document.createTextNode(white));
            }
        }
        btn.classList.remove('rot');
        btn.setAttribute('src' , 'res/moon.svg')
        menu.style.background = 'white';
        isMoon = false;
        document.body.style.color = 'rgba(0,0,0,.8)'
        arrow.setAttribute('src' , 'res/menu (3).svg')
        document.body.style.background = 'rgba(255, 255, 255, 0.8)';
    }
});




